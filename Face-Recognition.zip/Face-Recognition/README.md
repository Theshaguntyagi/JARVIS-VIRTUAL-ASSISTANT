# Face-Recognition in Python
Face Recognition tutorial refference for https://youtu.be/BG3mpdzk0Rw


# Prerequisites
[ Python 3.6.4 ]
[ OpenCV 3.4.1 or opencv-contrib-python 4.0 ]
[ Numpy ]
[ Pillow ]


# steps
[ run the Sample generator.py and enter a unique numeric id to create face samples with your face ]
[ run Model Trainer.py ]
[ run Face recognition.py ]
